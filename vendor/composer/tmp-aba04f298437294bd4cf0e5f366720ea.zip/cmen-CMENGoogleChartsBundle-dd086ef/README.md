# CMENGoogleChartsBundle

[![Latest Stable Version](https://poser.pugx.org/cmen/google-charts-bundle/v/stable)](https://packagist.org/packages/cmen/google-charts-bundle)
![CI](https://github.com/cmen/CMENGoogleChartsBundle/workflows/CI/badge.svg)
[![Total Downloads](https://img.shields.io/packagist/dt/cmen/google-charts-bundle.svg?style=flat)](https://packagist.org/packages/cmen/google-charts-bundle)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/cmen/CMENGoogleChartsBundle/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/cmen/CMENGoogleChartsBundle/)
[![License](https://poser.pugx.org/cmen/google-charts-bundle/license)](https://packagist.org/packages/cmen/google-charts-bundle)


`CMENGoogleChartsBundle` provides a Twig extension and PHP objects to display [Google Charts](https://developers.google.com/chart/) in your Symfony application.

## Documentation

* [Installation](Resources/doc/installation.md)
* [Basic usage](Resources/doc/basic_usage.md)
* [Code examples](Resources/doc/cookbook.md)
* [Diff charts](Resources/doc/diff_charts.md)
* [Events](Resources/doc/events.md)
* [Google Charts documentation](https://developers.google.com/chart/interactive/docs/)
* [How to contribute](Resources/doc/contribute.md)

## Examples
![Area](./Resources/doc/charts/area.png)
![Bubble](./Resources/doc/charts/bubble.png)
![Histo](./Resources/doc/charts/histo.png)
![Line](./Resources/doc/charts/line.png)
![Pie](./Resources/doc/charts/pie.png)
![Timeline](./Resources/doc/charts/timeline.png)

## License

This bundle is released under the MIT license. See the complete license in file LICENCE.
